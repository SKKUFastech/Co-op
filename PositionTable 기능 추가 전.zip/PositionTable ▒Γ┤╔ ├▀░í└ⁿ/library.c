#include "library.h"

char* get_time() {
    time_t currentTime;
    struct tm* timeInfo;
    char* timeString = (char*)malloc(9); // "hh:mm:ss" + null terminator

    if (timeString == NULL) {
        printf("메모리 할당 오류\n");
        return NULL;
    }

    // 시스템의 현재 시간 가져오기
    currentTime = time(NULL);

    // 현재 시간을 localtime 함수를 이용하여 시간 구조체에 저장
    timeInfo = localtime(&currentTime);

    // 시간:분:초 형식으로 문자열로 변환
    strftime(timeString, 9, "%H:%M:%S", timeInfo);
    return timeString;
}

/**@brief 명령전달에 쓰는 버퍼 내용을 터미널에 일단 보여주는 함수*/
 void print_buffer(uint8_t *array, size_t size) {
    for (size_t i = 0; i < size; i++) {
        printf("%02X ", array[i]);
    }
    printf("\n");
}

/**@brief  배열을 문자열로 변환하는 함수*/
char* array_to_string(const uint8_t *array, int size) {
    char *str = g_strdup_printf("%02X", array[0]); // 첫 번째 요소는 따로 처리

    char *temp;
    for (int i = 1; i < size; i++) { // 첫 번째 요소 이후의 요소들 처리
        temp = g_strdup_printf("%s %02X", str, array[i]);
        g_free(str);
        str = temp;
    }

    return str;
}
