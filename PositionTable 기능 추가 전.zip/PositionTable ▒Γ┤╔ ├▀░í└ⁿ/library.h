#ifndef LIBRARY_H  // 중복 포함 방지를 위한 전처리기 지시문
#define LIBRARY_H

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/select.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <time.h>
#include <inttypes.h>
#include <arpa/inet.h>
#include "ReturnCodes_Define.h"
#include "MOTION_EziSERVO2_DEFINE.h"

typedef uint8_t BYTE;
typedef unsigned long DWORD;
typedef unsigned short WORD;
typedef char* LPSTR;

#define BUFFER_SIZE 258
#define DATA_SIZE 253
#define PORT_UDP 3001 //UDP GUI
#define PORT_TCP 2001 //TCP GUI
#define TIMEOUT_SECONDS 2

void print_buffer(uint8_t *array, size_t size);
char* array_to_string(const unsigned char *array, int size);
char* get_time();

#endif
